ALEXITO STORE - PARCHES INCLUIDOS

FFTH BASIC (visibles en la interfaz):
- FFTH CUELLO OB55 -ALEXITO.3105
- FFTH PECHO CABEZA.3105

ARCHIVOS DE VALIDACIÓN (incluidos en el bundle, ocultos de la interfaz):
