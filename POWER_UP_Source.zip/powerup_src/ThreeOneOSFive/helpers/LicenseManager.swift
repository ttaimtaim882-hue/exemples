import Combine
import Foundation
import Security

@MainActor
final class LicenseManager: ObservableObject {
    static let accessKey = "CHECKONETRUE"
    static let keyPrefix = "POWER-"
    static let adminAPI  = "https://powerup-admin.up.railway.app/api"
    static let contactTelegram = "https://t.me/UP_POWER1"

    @Published private(set) var expirationDate: Date?
    @Published private(set) var isActive = false
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?
    @Published private(set) var contactOwner: String? = "UP_POWER1"
    @Published var rememberKey = true

    private let service = "com.powerup.cheat.activation"
    private let keyAccount = "license-key"
    private var lastAttemptAt: Date?

    init() {
        isActive = hasRememberedKey
    }

    var hasRememberedKey: Bool {
        !(string(for: keyAccount) ?? "").isEmpty
    }

    func beginLaunchSession() {
        checkMaintenance()
        isActive = hasRememberedKey
        message = isActive ? "✅ POWER UP Ready" : "Enter your POWER- key to continue"
    }

    func activate(key: String) {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmed.isEmpty, !isBusy else { return }
        if let lastAttemptAt, Date().timeIntervalSince(lastAttemptAt) < 1 {
            message = "Please wait before trying again"
            return
        }
        lastAttemptAt = Date()
        isBusy = true
        message = "Verifying POWER- key…"

        // Validate prefix
        guard trimmed.hasPrefix(Self.keyPrefix) else {
            isBusy = false
            message = "❌ Invalid key — must start with POWER-"
            return
        }

        // Check against admin API
        validateWithAdmin(key: trimmed)
    }

    private func validateWithAdmin(key: String) {
        guard let url = URL(string: "\(Self.adminAPI)/validate?key=\(key)") else {
            activateOffline(key: key)
            return
        }
        var req = URLRequest(url: url, timeoutInterval: 6)
        req.httpMethod = "GET"
        req.setValue("POWER UP App", forHTTPHeaderField: "User-Agent")

        URLSession.shared.dataTask(with: req) { [weak self] data, _, error in
            Task { @MainActor in
                guard let self else { return }
                if let error = error {
                    // Offline fallback — accept any POWER- key
                    self.activateOffline(key: key)
                    return
                }
                guard let data = data,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                    self.activateOffline(key: key)
                    return
                }
                let valid = json["valid"] as? Bool ?? false
                let expired = json["expired"] as? Bool ?? false
                let banned = json["banned"] as? Bool ?? false

                if banned {
                    self.isBusy = false
                    self.message = "🚫 Key banned — contact @UP_POWER1"
                } else if expired {
                    self.isBusy = false
                    self.message = "⏰ Key expired — get a new one"
                } else if valid {
                    self.isBusy = false
                    if self.rememberKey { self.save(key, for: self.keyAccount) }
                    self.isActive = true
                    self.message = "✅ POWER UP Activated"
                } else {
                    self.isBusy = false
                    self.message = "❌ Key not found — contact @UP_POWER1"
                }
            }
        }.resume()
    }

    private func activateOffline(key: String) {
        // Offline: accept any valid POWER- prefixed key
        isBusy = false
        if rememberKey { save(key, for: keyAccount) }
        isActive = true
        message = "✅ POWER UP Activated (Offline)"
    }

    private func checkMaintenance() {
        guard let url = URL(string: "\(Self.adminAPI)/status") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let maintenance = json["maintenance"] as? Bool,
                  maintenance == true else { return }
            Task { @MainActor in
                // Post notification for maintenance mode
                NotificationCenter.default.post(name: .maintenanceActive, object: nil)
            }
        }.resume()
    }

    func rememberedKey() -> String? { string(for: keyAccount) }

    func refresh() {
        isActive = hasRememberedKey
        message = isActive ? "✅ POWER UP Ready" : "Enter your POWER- key to continue"
    }

    func deactivate() {
        delete(keyAccount)
        isActive = false
        message = "Key removed from this device"
    }

    private func string(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func save(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

extension Notification.Name {
    static let maintenanceActive = Notification.Name("maintenanceActive")
}
