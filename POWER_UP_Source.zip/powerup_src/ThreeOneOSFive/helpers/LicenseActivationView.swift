import SwiftUI

struct LicenseActivationView: View {
    @ObservedObject var manager: LicenseManager
    @State private var key = ""
    @FocusState private var keyFocused: Bool
    @State private var logoOffset: CGFloat = -200
    @State private var logoOpacity: Double = 0
    @State private var logoGlow: CGFloat = 0
    @State private var maintenanceMode = false

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedHyperBackdrop()
                    .ignoresSafeArea()
                Color.black.opacity(0.25)
                    .ignoresSafeArea()

                // MAINTENANCE OVERLAY
                if maintenanceMode {
                    maintenanceOverlay
                } else {
                    ScrollViewReader { proxy in
                        ScrollView(showsIndicators: false) {
                            VStack(spacing: 0) {
                                Spacer(minLength: 20)

                                // ── LOGO — slides from top ──
                                logoSection

                                // ── KEY CARD ──
                                VStack(spacing: 16) {
                                    HStack(spacing: 10) {
                                        Image(systemName: manager.isBusy ? "arrow.triangle.2.circlepath" : "key.fill")
                                            .foregroundStyle(AppTheme.secondaryAccent)
                                            .font(.system(size: 16, weight: .bold))
                                        Text(manager.isBusy ? "Verifying…" : "Key required")
                                            .font(.system(size: 16, weight: .black, design: .rounded))
                                            .foregroundStyle(.white)
                                        Spacer()
                                    }

                                    Text("Enter your POWER- license key to continue")
                                        .font(.system(size: 13, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.68))
                                        .frame(maxWidth: .infinity, alignment: .leading)

                                    // Key field
                                    HStack {
                                        Image(systemName: "key.fill")
                                            .foregroundStyle(AppTheme.accent.opacity(0.7))
                                            .font(.system(size: 14))
                                        TextField("POWER-XXXXXX", text: $key)
                                            .focused($keyFocused)
                                            .textInputAutocapitalization(.characters)
                                            .autocorrectionDisabled()
                                            .submitLabel(.done)
                                            .onSubmit { activate() }
                                            .font(.system(size: 16, weight: .medium, design: .monospaced))
                                            .foregroundStyle(.white)
                                    }
                                    .padding(.horizontal, 16)
                                    .frame(height: 54)
                                    .background(Color.gray.opacity(0.22), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(AppTheme.accent.opacity(0.48), lineWidth: 1))
                                    .id("license-field")

                                    Toggle("Remember key on this device", isOn: $manager.rememberKey)
                                        .font(.system(size: 12, weight: .bold, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.72))
                                        .tint(AppTheme.accent)

                                    // ACTIVATE button
                                    Button(action: activate) {
                                        HStack(spacing: 9) {
                                            Image(systemName: manager.isBusy ? "hourglass" : "bolt.fill")
                                            Text(manager.isBusy ? "VERIFYING…" : "ACTIVATE")
                                        }
                                        .font(.system(size: 15, weight: .black, design: .rounded))
                                        .foregroundStyle(.white)
                                        .frame(maxWidth: .infinity, minHeight: 54)
                                        .background(
                                            LinearGradient(colors: [AppTheme.accent, AppTheme.secondaryAccent],
                                                           startPoint: .leading, endPoint: .trailing),
                                            in: RoundedRectangle(cornerRadius: 17, style: .continuous)
                                        )
                                        .shadow(color: AppTheme.accent.opacity(0.4), radius: 16, y: 8)
                                    }
                                    .buttonStyle(.plain)
                                    .disabled(key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || manager.isBusy)
                                    .opacity(key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.48 : 1)

                                    if let message = manager.message {
                                        Text(message)
                                            .font(.system(size: 12, weight: .bold, design: .rounded))
                                            .foregroundStyle(message.contains("✅") ? .green : .red.opacity(0.9))
                                            .multilineTextAlignment(.center)
                                            .frame(maxWidth: .infinity)
                                            .padding(.horizontal, 14)
                                            .padding(.vertical, 10)
                                            .background(Color.gray.opacity(0.20), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                    }

                                    // Telegram button
                                    Button {
                                        UIApplication.shared.open(URL(string: "https://t.me/UP_POWER1")!)
                                    } label: {
                                        HStack(spacing: 7) {
                                            Image(systemName: "paperplane.fill")
                                            Text("Get Key — @UP_POWER1")
                                        }
                                        .font(.system(size: 13, weight: .bold, design: .rounded))
                                        .foregroundStyle(AppTheme.secondaryAccent)
                                    }
                                    .buttonStyle(.plain)
                                }
                                .padding(20)
                                .background(.ultraThinMaterial.opacity(0.72), in: RoundedRectangle(cornerRadius: 25, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 25, style: .continuous).stroke(Color.white.opacity(0.16), lineWidth: 1))
                                .padding(.horizontal, 22)
                                .padding(.top, 20)
                                .id("activation-card")

                                Spacer(minLength: 42)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.bottom, 28)
                        }
                        .scrollDismissesKeyboard(.interactively)
                        .onChange(of: keyFocused) { focused in
                            guard focused else { return }
                            withAnimation(.easeOut(duration: 0.25)) {
                                proxy.scrollTo("activation-card", anchor: .center)
                            }
                        }
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear { animateLogo() }
        .onReceive(NotificationCenter.default.publisher(for: .maintenanceActive)) { _ in
            withAnimation { maintenanceMode = true }
        }
    }

    // ── LOGO ──
    private var logoSection: some View {
        VStack(spacing: 10) {
            // Logo image slides from top
            Image("PowerUpLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 180, height: 180)
                .shadow(color: AppTheme.accent.opacity(logoGlow), radius: 30)
                .shadow(color: AppTheme.secondaryAccent.opacity(logoGlow * 0.6), radius: 50)
                .offset(y: logoOffset)
                .opacity(logoOpacity)

            Text("POWER UP")
                .font(.system(size: 32, weight: .black, design: .rounded))
                .tracking(2)
                .foregroundStyle(
                    LinearGradient(colors: [.white, AppTheme.accent, AppTheme.secondaryAccent],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                .shadow(color: AppTheme.accent.opacity(0.5), radius: 10)
                .opacity(logoOpacity)

            Text("Version: 2.0  •  iOS Cheat")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.5))
                .opacity(logoOpacity)
        }
        .padding(.bottom, 10)
    }

    // ── MAINTENANCE ──
    private var maintenanceOverlay: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 20) {
                Image(systemName: "wrench.and.screwdriver.fill")
                    .font(.system(size: 64))
                    .foregroundStyle(AppTheme.accent)
                    .shadow(color: AppTheme.accent.opacity(0.5), radius: 20)
                Text("🔧 MAINTENANCE")
                    .font(.system(size: 32, weight: .black))
                    .foregroundStyle(.white)
                Text("POWER UP is under maintenance.\nCheck @UP_POWER1 for updates.")
                    .font(.system(size: 15))
                    .foregroundStyle(.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                Button {
                    UIApplication.shared.open(URL(string: "https://t.me/UP_POWER1")!)
                } label: {
                    HStack { Image(systemName: "paperplane.fill"); Text("@UP_POWER1") }
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 24).padding(.vertical, 12)
                        .background(AppTheme.accent, in: Capsule())
                }
            }
        }
    }

    // ── ANIMATIONS ──
    private func animateLogo() {
        withAnimation(.spring(response: 0.7, dampingFraction: 0.65).delay(0.1)) {
            logoOffset = 0
            logoOpacity = 1
        }
        withAnimation(.easeInOut(duration: 1.5).delay(0.5).repeatForever(autoreverses: true)) {
            logoGlow = 0.9
        }
    }

    private func activate() {
        keyFocused = false
        manager.activate(key: key)
    }
}
