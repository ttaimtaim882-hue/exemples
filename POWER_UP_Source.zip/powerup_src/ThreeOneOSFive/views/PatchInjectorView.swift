import SwiftUI
import UniformTypeIdentifiers

// ══════════════════════════════════════════════
// POWER UP — Patch Injector
// حقن ملفات .3105 داخل Free Fire MAX/FF
// ══════════════════════════════════════════════

struct Patch: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let fileName: String
    let sizeKB: Int
    let category: PatchCategory
    var isActive: Bool = false
    var isInjecting: Bool = false
    var injected: Bool = false

    enum PatchCategory: String, CaseIterable {
        case ffth    = "FFTH"
        case holo    = "HOLO"
        case drag    = "DRAG"
        case txt     = "TXT"
        case other   = "OTHER"

        var icon: String {
            switch self {
            case .ffth:  return "figure.stand"
            case .holo:  return "sparkles"
            case .drag:  return "arrow.down.to.line"
            case .txt:   return "doc.text.fill"
            case .other: return "puzzlepiece.fill"
            }
        }
        var color: Color {
            switch self {
            case .ffth:  return .blue
            case .holo:  return .purple
            case .drag:  return .orange
            case .txt:   return .green
            case .other: return .gray
            }
        }
    }
}

@MainActor
class PatchManager: ObservableObject {
    @Published var patches: [Patch] = []
    @Published var targetApp: TargetApp = .freeFire
    @Published var toast: String?
    @Published var showFilePicker = false

    enum TargetApp: String, CaseIterable {
        case freeFire    = "Free Fire"
        case freeFireMAX = "Free Fire MAX"
        var bundleID: String {
            switch self {
            case .freeFire:    return "com.dts.freefireth"
            case .freeFireMAX: return "com.dts.freefiremax"
            }
        }
        var icon: String {
            switch self {
            case .freeFire:    return "flame.fill"
            case .freeFireMAX: return "flame.circle.fill"
            }
        }
    }

    // مسارات الحقن المحتملة
    var injectPaths: [String] {
        let shared = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: "group.\(targetApp.bundleID)"
        )?.path
        let docs = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
        return [
            shared,
            docs.map { $0 + "/Patches" },
            "/var/mobile/Containers/Data/Application/\(targetApp.bundleID)/Documents/Patches",
            docs
        ].compactMap { $0 }
    }

    init() {
        loadBundledPatches()
    }

    func loadBundledPatches() {
        guard let bundlePath = Bundle.main.path(forResource: "BundledPatches", ofType: nil) else {
            loadDemoPatches(); return
        }
        let fm = FileManager.default
        guard let files = try? fm.contentsOfDirectory(atPath: bundlePath) else {
            loadDemoPatches(); return
        }
        patches = files.filter { $0.hasSuffix(".3105") }.map { name in
            let path = bundlePath + "/" + name
            let size = (try? fm.attributesOfItem(atPath: path)[.size] as? Int).map { $0 / 1024 } ?? 0
            return Patch(
                name: name.replacingOccurrences(of: ".3105", with: ""),
                fileName: name,
                sizeKB: size,
                category: detectCategory(name)
            )
        }
    }

    func loadDemoPatches() {
        patches = [
            Patch(name: "FFTH CUELLO OB55", fileName: "FFTH CUELLO OB55 -ALEXITO.3105", sizeKB: 45, category: .ffth),
            Patch(name: "FFTH PECHO ACTUALIZADO", fileName: "FFTH PECHO ACTUALIZADO.3105", sizeKB: 41, category: .ffth),
            Patch(name: "PECHO SIN CABEZA", fileName: "PECHO SIN CABEZA.3105", sizeKB: 40, category: .ffth),
            Patch(name: "HOLO PERSONAJES", fileName: "HOLO PERSONAJES.3105", sizeKB: 373, category: .holo),
            Patch(name: "HOLO PERSONAJE AMARILLO", fileName: "HOLO PERSONAJE AMARILLO.3105", sizeKB: 373, category: .holo),
            Patch(name: "HOLOGRAMA V2", fileName: "HOLOGRAMA V2.3105", sizeKB: 1452, category: .holo),
            Patch(name: "HOLOGRAMA VERDE", fileName: "HOLOGRAMA VERDE.3105", sizeKB: 1452, category: .holo),
            Patch(name: "HOLO AZUL ARMA", fileName: "HOLO AZUL ARMA.3105", sizeKB: 1452, category: .holo),
            Patch(name: "HOLO BLANCO Y CELESTE", fileName: "HOLO BLANCO Y CELESTE.3105", sizeKB: 1452, category: .holo),
            Patch(name: "HOLO RAIMBOW 2", fileName: "HOLO RAIMBOW 2.3105", sizeKB: 1452, category: .holo),
            Patch(name: "DRAG", fileName: "DRAG.3105", sizeKB: 45, category: .drag),
            Patch(name: "TXT 1", fileName: "TXT 1.3105", sizeKB: 2495, category: .txt),
            Patch(name: "TXT 2", fileName: "TXT 2.3105", sizeKB: 2495, category: .txt),
        ]
    }

    func detectCategory(_ name: String) -> Patch.PatchCategory {
        let n = name.uppercased()
        if n.contains("FFTH") { return .ffth }
        if n.contains("HOLO") { return .holo }
        if n.contains("DRAG") { return .drag }
        if n.contains("TXT")  { return .txt  }
        return .other
    }

    func togglePatch(_ id: UUID) {
        guard let idx = patches.firstIndex(where: { $0.id == id }) else { return }
        patches[idx].isActive.toggle()
        if patches[idx].isActive {
            inject(idx: idx)
        } else {
            removePatch(idx: idx)
        }
    }

    private func inject(idx: Int) {
        patches[idx].isInjecting = true
        patches[idx].injected = false

        let patch = patches[idx]
        let fm = FileManager.default

        // Try to get source file
        guard let srcURL = Bundle.main.url(
            forResource: patch.name,
            withExtension: "3105",
            subdirectory: "BundledPatches"
        ) ?? Bundle.main.url(forResource: patch.fileName, withExtension: nil, subdirectory: "BundledPatches"),
              let srcData = try? Data(contentsOf: srcURL) else {
            // Demo mode — create placeholder
            performInjectionDemo(idx: idx)
            return
        }

        // Write to all possible paths
        var success = false
        for basePath in injectPaths {
            do {
                try fm.createDirectory(atPath: basePath, withIntermediateDirectories: true)
                let dest = basePath + "/" + patch.fileName
                try srcData.write(to: URL(fileURLWithPath: dest))
                success = true
                break
            } catch {}
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
            self?.patches[idx].isInjecting = false
            self?.patches[idx].injected = success
            if success {
                self?.showToast("✅ \(patch.name) حُقن بنجاح")
            } else {
                self?.showToast("⚠️ حُفظ في Documents — شغل FF")
            }
        }
    }

    private func removePatch(idx: Int) {
        let patch = patches[idx]
        let fm = FileManager.default
        for basePath in injectPaths {
            let path = basePath + "/" + patch.fileName
            try? fm.removeItem(atPath: path)
        }
        patches[idx].injected = false
        showToast("🗑️ \(patch.name) أُزيل")
    }

    private func performInjectionDemo(idx: Int) {
        // Demo: simulate injection with fake data
        let patch = patches[idx]
        let fm = FileManager.default
        let docs = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let dir = docs + "/POWER_UP_Patches"
        try? fm.createDirectory(atPath: dir, withIntermediateDirectories: true)
        // Write metadata file
        let meta = "PATCH:\(patch.fileName)\nSIZE:\(patch.sizeKB)KB\nTARGET:\(targetApp.bundleID)\n"
        try? meta.write(toFile: dir + "/" + patch.name + ".txt", atomically: true, encoding: .utf8)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            self?.patches[idx].isInjecting = false
            self?.patches[idx].injected = true
            self?.showToast("✅ \(patch.name) جاهز في Documents")
        }
    }

    func importPatch(url: URL) {
        guard url.pathExtension == "3105" else {
            showToast("❌ ملف غير صالح — يجب .3105")
            return
        }
        let name = url.deletingPathExtension().lastPathComponent
        let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int).map { $0 / 1024 } ?? 0
        let patch = Patch(name: name, fileName: url.lastPathComponent, sizeKB: size, category: detectCategory(name))
        patches.insert(patch, at: 0)
        showToast("📦 \(name) أُضيف")
    }

    func showToast(_ msg: String) {
        toast = msg
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in
            self?.toast = nil
        }
    }

    func injectAll() {
        for i in patches.indices {
            patches[i].isActive = true
            inject(idx: i)
        }
    }

    func removeAll() {
        for i in patches.indices {
            if patches[i].isActive { removePatch(idx: i) }
            patches[i].isActive = false
        }
        showToast("🗑️ كل الباتشات أُزيلت")
    }
}

// ══════════════════════════════════════════════
// MAIN VIEW
// ══════════════════════════════════════════════
struct PatchInjectorView: View {
    @StateObject private var pm = PatchManager()
    @State private var selectedCategory: Patch.PatchCategory? = nil
    @State private var showImport = false

    var filtered: [Patch] {
        guard let cat = selectedCategory else { return pm.patches }
        return pm.patches.filter { $0.category == cat }
    }

    var activeCount: Int { pm.patches.filter { $0.isActive }.count }

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop().ignoresSafeArea()
            Color.black.opacity(0.22).ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                headerBar
                // Target Picker
                targetPicker
                // Category Filter
                categoryFilter
                // Patch List
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 10) {
                        ForEach(filtered) { patch in
                            PatchRowView(patch: patch) {
                                pm.togglePatch(patch.id)
                            }
                        }
                        if filtered.isEmpty {
                            Text("لا توجد باتشات في هذه الفئة")
                                .font(.system(size: 13, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.4))
                                .padding(30)
                        }
                    }.padding(.horizontal, 18).padding(.top, 10).padding(.bottom, 30)
                }
            }

            // Toast
            if let toast = pm.toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20).padding(.vertical, 11)
                        .background(.ultraThinMaterial, in: Capsule())
                        .padding(.bottom, 90)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
        .sheet(isPresented: $showImport) {
            PatchFilePicker { url in pm.importPatch(url: url) }
        }
    }

    // ── Header ──
    private var headerBar: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("PATCH INJECTOR")
                    .font(.system(size: 17, weight: .black, design: .rounded))
                    .tracking(1).foregroundStyle(.white)
                Text("\(pm.patches.count) patch • \(activeCount) active")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.accent.opacity(0.8))
            }
            Spacer()
            // Import button
            Button { showImport = true } label: {
                Image(systemName: "plus.circle.fill")
                    .font(.title2).foregroundStyle(AppTheme.accent)
            }
            // All ON/OFF
            Button { pm.injectAll() } label: {
                Text("ALL ON")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(AppTheme.accent.opacity(0.3), in: Capsule())
            }
            Button { pm.removeAll() } label: {
                Text("ALL OFF")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.6))
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(Color.white.opacity(0.08), in: Capsule())
            }
        }
        .padding(.horizontal, 18).padding(.top, 60).padding(.bottom, 12)
    }

    // ── Target ──
    private var targetPicker: some View {
        HStack(spacing: 8) {
            ForEach(PatchManager.TargetApp.allCases, id: \.self) { app in
                Button { pm.targetApp = app } label: {
                    HStack(spacing: 6) {
                        Image(systemName: app.icon)
                        Text(app.rawValue)
                    }
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(pm.targetApp == app ? .white : .white.opacity(0.4))
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(pm.targetApp == app ? AppTheme.accent.opacity(0.3) : Color.white.opacity(0.06),
                                in: Capsule())
                    .overlay(Capsule().stroke(pm.targetApp == app ? AppTheme.accent.opacity(0.6) : .clear, lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
            Spacer()
        }
        .padding(.horizontal, 18).padding(.bottom, 10)
    }

    // ── Category Filter ──
    private var categoryFilter: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                filterChip(label: "الكل", icon: "square.grid.2x2", cat: nil)
                ForEach(Patch.PatchCategory.allCases, id: \.self) { cat in
                    filterChip(label: cat.rawValue, icon: cat.icon, cat: cat)
                }
            }.padding(.horizontal, 18).padding(.bottom, 10)
        }
    }

    private func filterChip(label: String, icon: String, cat: Patch.PatchCategory?) -> some View {
        Button { selectedCategory = cat } label: {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11))
                Text(label).font(.system(size: 12, weight: .bold))
            }
            .foregroundStyle(selectedCategory == cat ? .white : .white.opacity(0.5))
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background(selectedCategory == cat ? AppTheme.accent.opacity(0.25) : Color.white.opacity(0.06),
                        in: Capsule())
            .overlay(Capsule().stroke(selectedCategory == cat ? AppTheme.accent.opacity(0.5) : .clear, lineWidth: 1))
        }.buttonStyle(.plain)
    }
}

// ══════════════════════════════════════════════
// PATCH ROW
// ══════════════════════════════════════════════
struct PatchRowView: View {
    let patch: Patch
    let onToggle: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            // Icon
            Image(systemName: patch.category.icon)
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(patch.category.color)
                .frame(width: 44, height: 44)
                .background(patch.category.color.opacity(0.12), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

            // Info
            VStack(alignment: .leading, spacing: 4) {
                Text(patch.name)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(.white).lineLimit(1)
                HStack(spacing: 8) {
                    Text(patch.category.rawValue)
                        .font(.system(size: 10, weight: .bold)).foregroundStyle(patch.category.color)
                        .padding(.horizontal, 7).padding(.vertical, 2)
                        .background(patch.category.color.opacity(0.12), in: Capsule())
                    Text("\(patch.sizeKB) KB")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.4))
                    if patch.injected {
                        Text("✓ INJECTED")
                            .font(.system(size: 9, weight: .black)).foregroundStyle(.green)
                    }
                }
            }
            Spacer()

            // Toggle
            if patch.isInjecting {
                ProgressView()
                    .tint(AppTheme.accent)
                    .scaleEffect(0.8)
            } else {
                Toggle("", isOn: .constant(patch.isActive))
                    .labelsHidden()
                    .tint(patch.isActive ? AppTheme.accent : nil)
                    .onTapGesture { onToggle() }
            }
        }
        .padding(14)
        .background(.ultraThinMaterial.opacity(0.5), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(patch.isActive ? AppTheme.accent.opacity(0.4) : Color.white.opacity(0.07), lineWidth: 1)
        )
        .animation(.spring(response: 0.3), value: patch.isActive)
        .animation(.spring(response: 0.3), value: patch.injected)
    }
}

// ══════════════════════════════════════════════
// FILE PICKER
// ══════════════════════════════════════════════
struct PatchFilePicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: [.data, .item])
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick) }
    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        init(onPick: @escaping (URL) -> Void) { self.onPick = onPick }
        func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            urls.first.map { onPick($0) }
        }
    }
}
